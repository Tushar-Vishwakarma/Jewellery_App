# NOTE:
 Create a new firebase project [here.] (https://console.firebase.google.com/)

#### Things to replace
      1. In the index.html,replace the firebase config.
      2. In services.js, replace the projectId with your firebase product id.

Please read the complete tutorial series [here.](http://www.arjunsk.com/tag/firebase/) 
